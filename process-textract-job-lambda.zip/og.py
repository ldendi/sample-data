
######################################################################################################################
 #  Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.                                           #
 #                                                                                                                    #
 #  Licensed under the Apache License, Version 2.0 (the License). You may not use this file except in compliance    #
 #  with the License. A copy of the License is located at                                                             #
 #                                                                                                                    #
 #      http://www.apache.org/licenses/LICENSE-2.0                                                                    #
 #                                                                                                                    #
 #  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES #
 #  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions    #
 #  and limitations under the License.                                                                                #
 #####################################################################################################################

import json
from trp import *
import boto3
import datetime

UNSUPPORTED_DATE_FORMAT = "UNSUPPORTED_DATE_FORMAT"
DOCTEXT = "docText"
KVPAIRS = "KVPairs"

def round_floats(o):
    if isinstance(o, float):
        return round(o, 4)
    if isinstance(o, dict):
        return {k: round_floats(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [round_floats(x) for x in o]
    return o


def prune_blocks(o):
    if(not isinstance(o, list)):
        ol = []
        ol.append(o)
        o = ol

    for page in o:
        for block in page['Blocks']:
            if 'Geometry' in block:
                del block['Geometry']['Polygon']

    return o

# This function will convert all the dates to a given format so as to enable search in an easy way for the users
def format_date(date):
    date_patterns = ["%m/%d/%Y", "%m-%d-%Y", "%B %Y", "%b %Y", "%m/%d/%y", "%B, %Y", "%Y", "%d-%m-%Y", "%B %d, %Y", "%b %d, %Y", "%Y."]
    for pattern in date_patterns:
        try:
            return datetime.datetime.strptime(date,pattern)
        except:
            pass
    print("Date format not matched {}".format(date))
    return UNSUPPORTED_DATE_FORMAT

class OutputGenerator:
    def __init__(self, response, forms, tables):
        self.response = response
        self.forms = forms
        self.tables = tables

        self.document = Document(self.response)

    def _outputText(self, page, p):
        text = page.text
        textInReadingOrder = page.getTextInReadingOrder()
        print(text)
        print(textInReadingOrder)
        
    def _outputForm(self, page, p):
        csvData = []
        key_value_pairs = {}
        for field in page.form.fields:
            csvItem = []
            if(field.key):
                csvItem.append(field.key.text)
            else:
                csvItem.append("")
            if(field.value):
                csvItem.append(field.value.text)
            else:
                csvItem.append("")
            csvData.append(csvItem)
            if ":" in csvItem[0]:
                csv_key = csvItem[0].split(":")[0]
            else:
                csv_key = csvItem[0]
            key_value_pairs[csv_key] = csvItem[1]
        csvFieldNames = ['Key', 'Value']
        print(csvFieldNames)
        print(csvData)
        return key_value_pairs

    def _outputTable(self, page, p):

        csvData = []
        for table in page.tables:
            csvRow = []
            csvRow.append("Table")
            csvData.append(csvRow)
            for row in table.rows:
                csvRow = []
                for cell in row.cells:
                    csvRow.append(cell.text)
                csvData.append(csvRow)
            csvData.append([])
            csvData.append([])
        print(csvData)


    def run(self):

        if(not self.document.pages):
            return
        print("Total Pages in Document: {}".format(len(self.document.pages)))
        print(json.dumps(self.response))

        docText = ""
        key_value_pairs = {}

        p = 1
        for page in self.document.pages:
            docText = docText + page.text + "\n"

            if(self.forms):
                key_val_pairs = self._outputForm(page, p)

            if(self.tables):
                self._outputTable(page, p)

            p = p + 1
        
        return {DOCTEXT: docText, KVPAIRS: key_val_pairs}
