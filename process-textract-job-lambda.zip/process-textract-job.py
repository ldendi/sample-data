import boto3
from helper import AwsHelper
from trp import Document
import json


def processRequest(request):

    print("Request : {}".format(request))

    jobId = request['jobId']
    jobAPI = request['jobAPI']
    fieldName = request['fieldName']

    client = AwsHelper().getClient('textract')
    response = client.get_document_analysis(JobId=jobId)
    
    doc = Document(response)
    fieldValue="NA"
    for page in doc.pages:
            try:
                key = fieldName
                field = page.form.getFieldByKey(key)
                if(field):
                    fieldValue = field.value
                    print("Key: {}, Value: {}".format(key, fieldValue))
                    return json.dumps('{"VaultCode":'+str(fieldValue)+'}')
            except Exception as e:
                print("In Exception")
                return json.dumps('{"VaultCode":'+fieldValue+'}')
    
def lambda_handler(event, context):
    #To Do, get the job status from SNS once jobstatus is published to SNS
    request = {}
    request["jobId"] = "d7a98d8087227fbb6615667f8d14d7fafdd7915e7928c5ca76efc029afe88d0a"
    request["jobAPI"] = "GetDocumentAnalysis"
    request["fieldName"] = "Vault Code"

    return processRequest(request)