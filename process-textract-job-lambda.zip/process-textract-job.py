import boto3
from helper import AwsHelper
from og import OutputGenerator

def getJobResults(api, jobId):

    pages = []

    client = AwsHelper().getClient('textract')
    response = client.get_document_analysis(JobId=jobId)
    pages.append(response)
    print("Resultset page recieved: {}".format(len(pages)))
    nextToken = None
    if('NextToken' in response):
        nextToken = response['NextToken']
        print("Next token: {}".format(nextToken))

    while(nextToken):
        try:
            if(api == "StartDocumentTextDetection"):
                response = client.get_document_text_detection(JobId=jobId, NextToken=nextToken)
            else:
                response = client.get_document_analysis(JobId=jobId, NextToken=nextToken)

            pages.append(response)
            print("Resultset page recieved: {}".format(len(pages)))
            nextToken = None
            if('NextToken' in response):
                nextToken = response['NextToken']
                print("Next token: {}".format(nextToken))

        except Exception as e:
            if(e.__class__.__name__ == 'ProvisionedThroughputExceededException'):
                print("ProvisionedThroughputExceededException.")
                print("Waiting for few seconds...")
                time.sleep(5)
                print("Waking up...")


    return pages

def processRequest(request):

    output = ""
    print("Request : {}".format(request))

    jobId = request['jobId']
    jobAPI = request['jobAPI']

    pages = getJobResults(jobAPI, jobId)

    print("Result pages recieved: {}".format(len(pages)))

    detectForms = False
    detectTables = False
    if(jobAPI == "StartDocumentAnalysis"):
        detectForms = True
        detectTables = True

    opg = OutputGenerator(pages, detectForms, detectTables)
    opg_output = opg.run()

    return {
        'statusCode': 200,
        'body': "Process Complete"
    }

def lambda_handler(event, context):
    #To Do, get the job status from SNS once jobstatus is published to SNS
    request = {}
    request["jobId"] = "c5d7f209fa14be7158281157fb618a7a9d644d8add9da5b5f21e178b4ca67a0c"
    request["jobAPI"] = "GetDocumentAnalysis"

    return processRequest(request)