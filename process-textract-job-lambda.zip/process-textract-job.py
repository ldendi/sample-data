from helper import AwsHelper
from trp import Document

def processRequest(request):

    print("Request : {}".format(request))

    jobId = request['jobId']
    jobAPI = request['jobAPI']
    fieldName = request['fieldName']

    client = AwsHelper().getClient('textract')
    response = client.get_document_analysis(JobId=jobId)
    
    doc = Document(response)
    fieldValue="NA"
    for page in doc.pages:
            try:
                key = fieldName
                field = page.form.getFieldByKey(key)
                if(field):
                    fieldValue = field.value
                    print("Key: {}, Value: {}".format(key, fieldValue))
                    return {"statusCode": 200, "VaultCode": str(fieldValue)}
            except Exception as e:
                print("In Exception")
                return {"statusCode": 200, "VaultCode": fieldValue}
    
def lambda_handler(event, context):
    #To Do, get the job status from SNS once jobstatus is published to SNS
    request = {}
    request["jobId"] = "c2c56f58a7c25151470d56146c4dc4774cfdf648f5448e00e026a04773dafcd1"
    request["jobAPI"] = "GetDocumentAnalysis"
    request["fieldName"] = "Vault Code"

    return processRequest(request)